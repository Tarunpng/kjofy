import { ImageResponse } from '@vercel/og';

export const config = { runtime: 'edge' };

// ── Device resolution map ──────────────────────────────────────
const SIZES = {
  iphone16promax:  [1320, 2868], iphone16pro:     [1206, 2622],
  iphone16plus:    [1290, 2796], iphone16:        [1179, 2556],
  iphone16e:       [1080, 2340],
  iphone17promax:  [1320, 2868], iphone17pro:     [1206, 2622],
  iphone17air:     [1179, 2556], iphone17:        [1179, 2556],
  iphone17e:       [1080, 2340],
  iphone15promax:  [1290, 2796], iphone15pro:     [1179, 2556],
  iphone15plus:    [1284, 2778], iphone15:        [1179, 2556],
  iphone14promax:  [1290, 2796], iphone14pro:     [1179, 2556],
  iphone14plus:    [1284, 2778], iphone14:        [1170, 2532],
  iphone13promax:  [1284, 2778], iphone13pro:     [1170, 2532],
  iphone13:        [1170, 2532], iphone13mini:    [1080, 2340],
  iphone12promax:  [1284, 2778], iphone12pro:     [1170, 2532],
  iphone12:        [1170, 2532], iphone12mini:    [1080, 2340],
  iphone11promax:  [1242, 2688], iphone11pro:     [1125, 2436],
  iphone11:        [828,  1792], iphonexsmax:     [1242, 2688],
  iphonexs:        [1125, 2436], iphonexr:        [828,  1792],
  iphonese3:       [750,  1334], iphonese2:       [750,  1334],
  // Android – 1080×2400 default for most flagships
  default:         [1080, 2400],
};

function getSize(model) {
  if (!model) return SIZES.default;
  const key = model.toLowerCase().replace(/[^a-z0-9]/g, '');
  return SIZES[key] || SIZES.default;
}

// ── Simple deterministic hash ──────────────────────────────────
function hash(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = (h * 16777619) >>> 0;
  }
  return h;
}

// ── Bollywood dialogues ────────────────────────────────────────
const DIALOGUES = [
  { text: "Mogambo\nKhush Hua", movie: "— Mr. India (1987)" },
  { text: "Kitne Aadmi\nThe?", movie: "— Sholay (1975)" },
  { text: "Mere Paas\nMaa Hai", movie: "— Deewar (1975)" },
  { text: "Rishte Mein Toh\nHum Tumhare\nBaap Lagte Hain", movie: "— Andaz Apna Apna (1994)" },
  { text: "Babumoshai,\nZindagi Badi Honi\nChahiye, Lambi Nahi", movie: "— Anand (1971)" },
  { text: "Pushpa,\nI Hate Tears", movie: "— Amar Prem (1972)" },
  { text: "Don Ko Pakadna\nMushkil Hi Nahi,\nNaamumkin Hai", movie: "— Don (1978)" },
  { text: "Bade Bade Deshon\nMein Aisi Chhoti\nChhoti Baatein\nHoti Rehti Hain", movie: "— DDLJ (1995)" },
  { text: "Ja Simran Ja,\nJee Le Apni\nZindagi", movie: "— DDLJ (1995)" },
  { text: "Palat...\nPalat...", movie: "— DDLJ (1995)" },
  { text: "Hum Jahan\nKhade Hote Hain,\nLine Wahin Se\nShuru Hoti Hai", movie: "— Deewar (1975)" },
  { text: "Picture Abhi\nBaaki Hai\nMere Dost", movie: "— Om Shanti Om (2007)" },
  { text: "Thappad Se\nDarr Nahi Lagta,\nPyaar Se Lagta Hai", movie: "— Dabangg (2010)" },
  { text: "All Izz Well", movie: "— 3 Idiots (2009)" },
  { text: "Apna Time\nAayega", movie: "— Gully Boy (2019)" },
  { text: "How's The Josh?\nHigh Sir!", movie: "— Uri (2019)" },
  { text: "Tareekh Pe\nTareekh,\nTareekh Pe\nTareekh", movie: "— Damini (1993)" },
  { text: "Main Aaj Bhi\nPheke Hue Paise\nNahi Uthata", movie: "— Agneepath (1990)" },
  { text: "Dosti Ka Ek\nUsool Hai Madam:\nNo Sorry,\nNo Thank You", movie: "— Maine Pyar Kiya (1989)" },
  { text: "Haar Ke Jeetne\nWale Ko Baazigar\nKehte Hain", movie: "— Baazigar (1993)" },
  { text: "Tension Lene Ka\nNahi, Dene Ka", movie: "— Munna Bhai MBBS (2003)" },
  { text: "Jaadu Ki Jhappi", movie: "— Munna Bhai MBBS (2003)" },
  { text: "Yeh Baburao\nKa Style Hai", movie: "— Hera Pheri (2000)" },
  { text: "25 Din Mein\nPaisa Double", movie: "— Hera Pheri (2000)" },
  { text: "Main Apni\nFavourite Hoon", movie: "— Jab We Met (2007)" },
  { text: "Sattar Minute!\nSattar Minute!", movie: "— Chak De India (2007)" },
  { text: "Itni Shiddat Se\nMaine Tumhe\nPaane Ki Koshish\nKi Hai", movie: "— Om Shanti Om (2007)" },
  { text: "Ek Chutki Sindoor\nKi Keemat\nTum Kya Jaano\nRamesh Babu", movie: "— Om Shanti Om (2007)" },
  { text: "Life Mein Sabse\nBada Risk Hai\nKi Koi Risk\nNa Lena", movie: "— ZNMD (2011)" },
  { text: "Kehte Hain Agar\nKisi Cheez Ko\nDil Se Chaho\nToh Puri Qainaat\nMila Deti Hai", movie: "— Om Shanti Om (2007)" },
  { text: "Kuch Kuch Hota Hai,\nTum Nahi Samjhoge", movie: "— KKHH (1998)" },
  { text: "Success Ke Peeche\nMat Bhago,\nExcellent Bano", movie: "— 3 Idiots (2009)" },
  { text: "Kabhi Kabhi Jeetne\nKe Liye Kuch\nHaarna Padta Hai", movie: "— Jeet (1996)" },
  { text: "Main Hoon Na", movie: "— Main Hoon Na (2004)" },
  { text: "Kal Ho Na Ho.\nLive Every Moment.", movie: "— Kal Ho Na Ho (2003)" },
  { text: "Yeh Haath\nMujhe De De\nThakur", movie: "— Sholay (1975)" },
  { text: "Basanti,\nIn Kutton Ke Saamne\nMat Naachna", movie: "— Sholay (1975)" },
  { text: "Poora Naam\nVijay Dinanath\nChauhan", movie: "— Agneepath (1990)" },
  { text: "K-K-K-Kiran", movie: "— Darr (1993)" },
  { text: "Swagat Nahi\nKaroge Hamara?", movie: "— Tiger Zinda Hai (2017)" },
  { text: "Wrong Number", movie: "— PK (2014)" },
  { text: "Aati Kya Khandala?", movie: "— Ghulam (1998)" },
  { text: "Parampara,\nPratishtha,\nAnushasan", movie: "— Mohabbatein (2000)" },
  { text: "Bohot Hard\nBohot Hard", movie: "— Gully Boy (2019)" },
  { text: "Keh Ke Lunga", movie: "— Gangs of Wasseypur (2012)" },
  { text: "Mhaari Chhoriyaan\nChhoriyon Se\nKam Hain Ke?", movie: "— Dangal (2016)" },
  { text: "Aata Majhi Satakli", movie: "— Singham (2011)" },
  { text: "O Stree,\nRaksha Karna", movie: "— Stree (2018)" },
  { text: "Main Jhukega Nahi\nSaala", movie: "— Pushpa (2021)" },
  { text: "Flower Nahi,\nFire Hai Main", movie: "— Pushpa (2021)" },
  { text: "Pushparaj Ko\nKoi Rok Nahi Sakta", movie: "— Pushpa 2 (2024)" },
  { text: "History Thoda\nRepeat Hogi", movie: "— KGF (2018)" },
  { text: "Sapna Wahi Dekhna\nJo Pura Kar Sako", movie: "— MS Dhoni (2016)" },
  { text: "Crime Master Gogo\nNaam Hai Mera", movie: "— Andaz Apna Apna (1994)" },
  { text: "Ghajab Bezati Hai\nYaar!", movie: "— Stree (2018)" },
  { text: "Desh Ki Mitti\nKo Namaskar", movie: "— Upkar (1967)" },
  { text: "Bhaag DK\nBose!", movie: "— Delhi Belly (2011)" },
  { text: "Akash Ko\nKuch Nahi\nDikhta... Ya\nDikhta Hai?", movie: "— Andhadhun (2018)" },
  { text: "Loser Woh\nNahi Jo\nHaar Jaaye,\nLoser Woh\nHai Jo Try\nHi Na Kare", movie: "— Chhichhore (2019)" },
  { text: "Yeh Dil\nMaange More,\nDimple", movie: "— Shershaah (2021)" },
  { text: "Am I Looking\nHot Today?", movie: "— K3G, Poo (2001)" },
  { text: "Gorgeous!\nGorgeous!\nGorgeous!", movie: "— K3G, Poo (2001)" },
  { text: "Tenu Le Ke\nJaunga Main", movie: "— DDLJ (1995)" },
  { text: "Main Akeli\nNahi Hoon,\nMain Apne\nSaath Hoon", movie: "— Queen (2014)" },
  { text: "Antakshari\nKhelte Hain", movie: "— Hum Aapke Hain Koun (1994)" },
  { text: "Teja Main\nHoon, Mark\nIdhar Hai", movie: "— Andaz Apna Apna (1994)" },
  { text: "Yeh Dosti\nHum Nahi\nTodenge", movie: "— Sholay (1975)" },
  { text: "Bhaag Milkha\nBhaag", movie: "— Bhaag Milkha Bhaag (2013)" },
  { text: "Violence,\nViolence,\nViolence", movie: "— KGF Chapter 2 (2022)" },
  { text: "Gandhigiri\nZindabad!", movie: "— Lage Raho Munna Bhai (2006)" },
  { text: "Jab Pyaar Kiya\nToh Darna Kya", movie: "— Mughal-E-Azam (1960)" },
  { text: "Mard Ko Dard\nNahi Hota", movie: "— MKDNH (2019)" },
  { text: "Koi Bhi Desh\nPerfect Nahi Hota,\nUsse Perfect\nBanana Padta Hai", movie: "— Rang De Basanti (2006)" },
  { text: "Seize The Day.\nPal Mein Hai\nZindagi", movie: "— ZNMD (2011)" },
  { text: "Dil Chahta Hai,\nChhupaye Na Chhupe", movie: "— Dil Chahta Hai (2001)" },
  { text: "Pathaan\nAa Gaya", movie: "— Pathaan (2023)" },
  { text: "Tiger Abhi\nZinda Hai", movie: "— Tiger Zinda Hai (2017)" },
  { text: "Bajrangi\nBhaijaan\nAaya Re!", movie: "— Bajrangi Bhaijaan (2015)" },
  { text: "Kabhi Alvida\nNaa Kehna", movie: "— KANK (2006)" },
  { text: "Main Udna\nChahta Hoon,\nDaudna Chahta Hoon,\nGirna Bhi\nChahta Hoon", movie: "— Yeh Jawaani Hai Deewani (2013)" },
  { text: "Har Pal Yahan\nJee Bhar Jiyo,\nJo Hai Samaa\nKal Ho Na Ho", movie: "— Kal Ho Na Ho (2003)" },
  { text: "Zindagi Na\nMilegi Dobara,\nKar Le Jo\nKarna Hai", movie: "— ZNMD (2011)" },
  { text: "Jawan Hai\nToh Jawab\nDunga", movie: "— Jawan (2023)" },
  { text: "Salaam\nNamaste!", movie: "— Salaam Namaste (2005)" },
  { text: "Koi Tumhe Tab Tak\nNahi Hara Sakta\nJab Tak Tum Khud Se\nNa Haar Jao", movie: "— Sultan (2016)" },
  { text: "Zindagi Lambi\nNahi, Badi\nHoni Chahiye", movie: "— Anand (1971)" },
  { text: "Sirf 70 Minute\nHain Mere Paas", movie: "— Chak De India (2007)" },
  { text: "I Can Talk\nEnglish,\nI Can Walk\nEnglish", movie: "— Namak Halaal (1982)" },
  { text: "Aaj Khush Toh\nBahut Hoge Tum", movie: "— Deewar (1975)" },
  { text: "Mumbai Ka King\nKaun? Don!", movie: "— Don (1978)" },
  { text: "Anand Kumar\nKe Bacche\nIIT Jayenge", movie: "— Super 30 (2019)" },
];

export default async function handler(req) {
  try {
    const { searchParams } = new URL(req.url);
    const model  = searchParams.get('model')  || 'default';
    const seed   = searchParams.get('seed')   || 'guest';

    // Daily rotation: same user gets same wallpaper per day, different tomorrow
    const today  = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    const idx    = hash(today + seed) % DIALOGUES.length;
    const { text, movie } = DIALOGUES[idx];

    const [width, height] = getSize(model);
    const scale = width / 1170;

    // Load fonts at runtime
    const [serifFont, serifItalic] = await Promise.all([
      fetch('https://fonts.gstatic.com/s/instrumentserif/v6/From_-BRRCQzJkZxvxTBGNiGo8iooyiE.woff2').then(r => r.arrayBuffer()),
      fetch('https://fonts.gstatic.com/s/instrumentserif/v6/From_-BRRCQzJkZxvxTBGNiGo8irAyyiEhj_Q.woff2').then(r => r.arrayBuffer()),
    ]);

    const dialogueSize = Math.max(56, Math.round(90 * scale));
    const movieSize    = Math.max(28, Math.round(38 * scale));
    const brandSize    = Math.max(20, Math.round(26 * scale));
    const paddingX     = Math.round(100 * scale);

    return new ImageResponse(
      (
        <div
          style={{
            width: '100%',
            height: '100%',
            background: '#0C0C0C',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            position: 'relative',
            fontFamily: '"Instrument Serif"',
            paddingLeft: paddingX,
            paddingRight: paddingX,
          }}
        >
          {/* Warm radial glow */}
          <div
            style={{
              position: 'absolute',
              top: 0, left: 0, right: 0, bottom: 0,
              background: 'radial-gradient(ellipse 80% 50% at 50% 50%, rgba(232,184,73,0.06) 0%, transparent 70%)',
              display: 'flex',
            }}
          />

          {/* Top accent line */}
          <div
            style={{
              position: 'absolute',
              top: 0, left: 0, right: 0,
              height: Math.round(3 * scale),
              background: 'linear-gradient(90deg, transparent, #E8B849, transparent)',
              display: 'flex',
            }}
          />

          {/* Dialogue */}
          <div
            style={{
              fontSize: dialogueSize,
              color: '#F0EDE6',
              textAlign: 'center',
              lineHeight: 1.15,
              letterSpacing: '-0.02em',
              whiteSpace: 'pre-line',
              zIndex: 1,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
            }}
          >
            {text}
          </div>

          {/* Movie name */}
          <div
            style={{
              marginTop: Math.round(48 * scale),
              fontSize: movieSize,
              color: '#E8B849',
              fontStyle: 'italic',
              letterSpacing: '0.01em',
              zIndex: 1,
              display: 'flex',
            }}
          >
            {movie}
          </div>

          {/* Branding */}
          <div
            style={{
              position: 'absolute',
              bottom: Math.round(72 * scale),
              fontSize: brandSize,
              color: 'rgba(255,255,255,0.18)',
              letterSpacing: '0.12em',
              zIndex: 1,
              display: 'flex',
            }}
          >
            KJOFY.COM
          </div>
        </div>
      ),
      {
        width,
        height,
        fonts: [
          { name: 'Instrument Serif', data: serifFont,   style: 'normal', weight: 400 },
          { name: 'Instrument Serif', data: serifItalic, style: 'italic', weight: 400 },
        ],
      }
    );
  } catch (err) {
    return new Response(`Error generating wallpaper: ${err.message}`, { status: 500 });
  }
}
